
export class User {
    constructor(
    firstname: string,
    lastname: string,
    username: string, 
    password: string
    ){}
}